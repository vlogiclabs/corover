$(document).ready(function () {
	$('.datepicker').datepicker({
      autoclose: true
    });
});