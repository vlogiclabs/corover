<?php $__env->startSection('content-header'); ?>;
<h1 >drgggddggdfdh </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

dfdfgdg
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>