<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<htmL>
<head>
<title>Insert Data into mongo</title>
</head>
</body>
 <div class="box">
            <div class="box-header">
              <h3 class="box-title">Condensed Full Width Table</h3>
            </div>
<?php $data = json_decode($data); ?>
 <div class="box-body no-padding">
<table border="1" class="table table-bordered">
<tr><th> id <th> name <th> address <th> </th></tr>
<?php foreach($data as $data): ?>
<tr><td> <?php echo $data->_id; ?> </td>
<td> <?php echo $data->name; ?> </td>
<td> <?php echo $data->address; ?> </td>
<td><a href="edit/<?php echo $data->_id; ?> ">Edit</a></td></tr>
<?php endforeach; ?>
</table>
</div>
</body>
</html>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>