<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Anything you want
    </div>
    <script src="https://code.jquery.com/jquery-2.1.3.js"></script>
    <!-- Default to the left -->
    <strong>Copyright © 2017 <a href="#">Company</a>.</strong> All rights reserved.
</footer>