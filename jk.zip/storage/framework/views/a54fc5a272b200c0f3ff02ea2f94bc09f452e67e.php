<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<htmL>
<head>
<title>Insert Data into mongo</title>
  </head>
   <body>
   <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
   <?php endif; ?>

    <div class="box">
      <div class="box-header">
        <h3 class="box-title">Users Listings</h3>
   </div>

     <div class="box-body no-padding">
           <?php //$data = json_decode($data);
                foreach($data as $data){
                 print_r($data['_id']);
                }
                
                 ?>
             
       </div>
     </div>
   </body>
</html>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>