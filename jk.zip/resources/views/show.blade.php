@extends('admin_template')

@section('content-header');
<h1 >drgggddggdfdh </h1>
@endsection

@section('content')

dfdfgdg
   
@endsection